enum CustomTextFieldType{Name, Email, Password, Pickup, DropOff, Package}
