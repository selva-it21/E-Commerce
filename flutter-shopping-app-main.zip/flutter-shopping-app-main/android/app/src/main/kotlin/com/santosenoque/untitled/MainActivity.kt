package com.santosenoque.untitled

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
